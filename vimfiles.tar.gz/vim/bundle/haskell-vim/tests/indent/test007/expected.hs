data Customer = Customer
  { customerID      :: CustomerID
  , customerName    :: String
  , customerAddress :: Address
  } deriving (Show)
