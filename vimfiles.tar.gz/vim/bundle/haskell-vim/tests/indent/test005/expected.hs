[ (NS spotify spotify (className =? "Spotify") doFullFloat )
,  ]
