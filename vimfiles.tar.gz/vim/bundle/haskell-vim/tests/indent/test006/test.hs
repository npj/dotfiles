foo = doSomething 123  -- Do something important.
