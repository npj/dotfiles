data Foo
  = Foo
    { foo :: Int
    , bar :: Char
    , baz :: Int
    } deriving (Eq, Ord)
