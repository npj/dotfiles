-- | This is a function.
fun  -- this shouldn't be indented
