    foo x
      | x == x = True

