add1 x = x + y
  where
    y = 1
