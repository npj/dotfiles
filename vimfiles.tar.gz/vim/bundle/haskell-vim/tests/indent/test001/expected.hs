data Foo = Foo
  { foo :: Int
-- comment
  , bar :: Int
  }
