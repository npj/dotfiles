# Contributing 

We like help. If you want to make some changes feel free to open up a pull request and We'll gladly merge it.
