| normal |no space|  2 spaces  ||
| - |-|  --- ||
| normal |no space|  2 spaces  ||

The table above is the first thing in the file.

The following table is already well formatted. It should not be modified:

| a | b |
|---|---|
| c | d |

The following table is the last thing in the file:

| normal |no space|  2 spaces  ||
| - |-|  --- ||
| normal |no space|  2 spaces  ||
